function toggleMenu() {
  const nav = document.getElementById("navbar");
  nav.classList.toggle("show");
}

// (Form removed from contact page; simple helper kept if needed elsewhere)
function sendMessage(event) {
  event.preventDefault();
  const name = document.getElementById('contact-name')?.value || '';
  alert(`Thank you, ${name || 'visitor'} — your message has been received. We'll contact you soon.`);
  document.getElementById('contact-form')?.reset();
}
